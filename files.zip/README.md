# Punkteschnitt – Notenverwaltung als installierbare App

Diese App läuft als **PWA (Progressive Web App)**. Das ist der realistische Weg, um
eine "echte", installierbare App zu bauen, ohne Android Studio / Xcode auf deinem
PC einzurichten:

- Auf **Android**: Installation wie eine normale App (eigenes Icon, eigenes Fenster
  ohne Browserleiste, funktioniert offline).
- Auf **iPhone**: Installation über Safari → "Zum Home-Bildschirm" → verhält sich
  dann ebenfalls wie eine eigenständige App.

Eine App im Play Store / App Store zu veröffentlichen würde ein Entwicklerkonto,
Android Studio bzw. Xcode und (bei iOS) einen Mac erfordern – das ist für ein
privates Notenverwaltungs-Tool nicht nötig.

## Was ist enthalten

- `index.html` – die eigentliche App (Oberfläche + Logik, alles in einer Datei)
- `manifest.json` – macht die App installierbar
- `sw.js` – Service Worker, sorgt für Offline-Funktion
- `icon-192.png`, `icon-512.png` – App-Icons

Alle Daten (Fächer, Noten) werden **lokal auf deinem Handy** gespeichert
(`localStorage`), es gibt keinen Server und keine Cloud-Anbindung.

## Installation auf dem Handy (Schritt für Schritt)

Eine PWA muss über eine echte Web-Adresse (HTTPS) aufgerufen werden – nicht als
lokale Datei. Der einfachste kostenlose Weg dafür ist **GitHub Pages**:

1. Gehe auf [github.com](https://github.com) und erstelle (falls noch nicht
   vorhanden) einen kostenlosen Account.
2. Erstelle ein neues Repository, z. B. `punkteschnitt` (öffentlich, ohne README).
3. Lade die 5 Dateien aus diesem Ordner in das Repository hoch (auf GitHub:
   "Add file" → "Upload files", alle 5 Dateien auswählen, "Commit changes").
4. Gehe im Repository auf **Settings → Pages**.
5. Wähle bei "Branch" den Branch `main` und Ordner `/ (root)`, dann **Save**.
6. Nach ca. 1 Minute ist die App erreichbar unter:
   `https://DEIN-BENUTZERNAME.github.io/punkteschnitt/`
7. Öffne diesen Link auf deinem Handy:
   - **Android (Chrome):** Menü (⋮) → "App installieren" bzw. "Zum Startbildschirm
     hinzufügen".
   - **iPhone (Safari):** Teilen-Symbol → "Zum Home-Bildschirm".
8. Fertig – die App erscheint als eigenes Icon auf deinem Startbildschirm.

## Alternative ohne GitHub

Falls du GitHub nicht nutzen willst, funktioniert jeder andere kostenlose
Static-Hosting-Dienst genauso (z. B. Netlify oder Cloudflare Pages): einfach den
Ordner dort hochladen/hineinziehen, fertig ist die HTTPS-Adresse.

## Benutzung

- Oben rechts: Halbjahr auswählen (Q11/1, Q11/2, Q12/1, Q12/2 – unter
  "Halbjahre" erweiterbar/anpassbar).
- **+ Fach**: neues Fach für das aktuelle Halbjahr anlegen.
- Auf ein Fach tippen → Noten einsehen, mit dem runden **+**-Button unten rechts
  neue Noten eintragen (0–15 Punkte, "klein" = ×1, "groß" = ×2 Gewichtung).
- Die Übersicht zeigt automatisch den gewichteten Punkteschnitt je Fach sowie den
  Gesamtschnitt über alle Fächer des Halbjahres.

## Später erweitern

Wenn du willst, kann die App später erweitert werden um z. B.:
- Abiturschnitt-Berechnung über alle vier Halbjahre
- Export/Backup der Daten (JSON-Datei)
- Fächer mit individueller Gewichtung fürs Abitur (z. B. Kernfächer ×2)

Sag einfach Bescheid, dann bauen wir das direkt mit ein.
